library(dplyr)
library(readr)
counts <- Indicators %>%
group_by(IndicatorCode, IndicatorName) %>%
summarise(NumCountries = n_distinct(CountryName),
NumYears = n_distinct(Year),
FirstYear = min(Year),
LastYear = max(Year))

