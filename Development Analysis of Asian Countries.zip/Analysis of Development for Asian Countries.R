library(shiny)
library(igraph)
library(network)
library(sna)
library(ndtv)
library(extrafont)
library(networkD3)
library(shinythemes)
library(readr)
library(stats)
library(base)
library(rworldmap)
library(animation)
library(caTools)
library(RColorBrewer)
library(classInt)
library(data.table, warn.conflicts = FALSE, quietly = TRUE)
library(dplyr, warn.conflicts = FALSE, quietly = TRUE)
library(dtplyr, warn.conflicts = FALSE, quietly = TRUE)
library(ggplot2, warn.conflicts = FALSE, quietly = TRUE)
library(tidyr, warn.conflicts = FALSE, quietly = TRUE)
library(maps, warn.conflicts = FALSE, quietly = TRUE)
library(reshape)
library(graphics)
library(reshape2)
library(plotly)


ui <- fluidPage(theme = shinytheme("superhero"),
                
                titlePanel(title=h1("Analysis of Development of Asian Countries", align="center")),
                
                sidebarPanel(
                  br(),
                  h4(helpText("")),
                  
                  selectInput("Type", label = h3("Select the Category:"), choices = c("Asia","Asia and World")),
                  conditionalPanel(condition = "input.Type == 'Asia and World'",
                                   selectInput("Indicators", label = h3("Select indicators:"), as.list(counts$IndicatorName)),
                                   uiOutput("years")
                                  
                  ),
                 
                  actionButton(inputId = "go", label = "RUN")
                  ),
                
                mainPanel(
                  uiOutput("type")
                )
)   


server <- shinyServer(function(input, output){
  
  output$years <- renderUI({
    id <- input$Indicators
    id <- counts[counts$IndicatorName == id,]
    conditionalPanel(condition = "input.Indicators = id",
                     sliderInput("Years", label = h3("Select the year:"), value = 2000, min = id$FirstYear, max = id$LastYear,step = 1 ))
  })
  output$type <- renderUI({
    check1 <- input$Type == "Asia and World"
    check2 <- input$Type == "Asia"
    
    if( check1) {
      tabsetPanel(
        tabPanel("Map",
                 plotOutput(outputId = "plot1")),
        tabPanel("Tabular View",
                 tableOutput("table")),
        tabPanel("Clusters", 
                 plotOutput(outputId = "plot2")
        ),
        tabPanel("TOP 10s", plotOutput(outputId = "plot3")),
        tabPanel("BOTTOM 10s", plotOutput(outputId = "plot4"))
      )
    }
    
    else if(check2){
      tabsetPanel(
        tabPanel("Communication Stats", h3("Telephone Subscribers"),plotOutput(outputId = "plot5"), h3("Mobile Data Subcriptions"),
                 plotOutput(outputId = "plot6")),
        tabPanel("Population Stats", h3("Population in largest city"), plotOutput(outputId = "plot7"), 
                 h3("Population distribution by age groups in percents"),plotOutput(outputId = "plot8"),
                 h3("Percentage of total female population"),plotOutput(outputId = "plot9"),
                 h3("Population growth in annual percentage"),plotOutput(outputId = "plot10")),
        tabPanel("Electricity Stats", h3("Electricity production"),plotOutput(outputId = "plot11"),
                 h3("Electric Power Consumption"),plotOutput(outputId = "plot12")),
        tabPanel("Birth Stats", h3("life expectancies at birth (years)"),plotOutput(outputId = "plot13"),
                 h3("Fertility Rates"),plotOutput(outputId = "plot14")),
        tabPanel("Hospital Stats", h3("hospital beds per 1000 persons"),plotOutput(outputId = "plot15")),
        tabPanel("Food and Water Stats", h3("food imports and exports"),plotOutput(outputId = "plot16"),
                 h3("improved water source"),plotOutput(outputId = "plot17")),
        tabPanel("Fuels Stats", h3("fuels pump prices"),plotOutput(outputId = "plot18")),
        tabPanel("Unemployment Stats", h3("Unemployment by education level"),plotOutput(outputId = "plot19")),
        tabPanel("Defense Stats", h3("Arms Imports"),plotlyOutput(outputId = "plot20"),
                 h3("Arms Exports"), plotlyOutput(outputId = "plot21"),
                 h3("Armed Forces(Total Personnel)"),plotlyOutput(outputId = "plot22"),
                 h3("Military Expenditure"),plotlyOutput(outputId = "plot23"),
                 h3("Military Expenditure (% of GDP)"),plotlyOutput(outputId = "plot24"))
        
        
      )
    }
    
    else{
      print("Not Applicable")
    }
    
  })
                      data <- eventReactive(input$go,{
                        id <- input$Indicators
                        id <- counts[counts$IndicatorName == id,]
                      })
                      data1 <- eventReactive(input$go,{
                        indicatorName <- input$Indicators
                        indicatorYear <- input$Years
                        filtered <- Indicators[Indicators$IndicatorName==indicatorName & Indicators$Year==indicatorYear,]
                        correction <- c("Antigua and Barbuda"="Antigua", "Bahamas, The"="Bahamas", 
                                        "Brunei Darussalam"="Brunei", "Cabo Verde"="Cape Verde",
                                        "Congo, Dem. Rep."="Democratic Republic of the Congo", 
                                        "Congo, Rep."="Republic of Congo", "Cote d'Ivoire"="Ivory Coast", 
                                        "Egypt, Arab Rep."="Egypt", "Faeroe Islands"="Faroe Islands", 
                                        "Gambia, The"="Gambia", "Iran, Islamic Rep."="Iran", 
                                        "Korea, Dem. Rep."="North Korea", "Korea, Rep."="South Korea",
                                        "Kyrgyz Republic"="Kyrgyzstan", "Lao PDR"="Laos", "Macedonia, FYR"="Macedonia", 
                                        "Micronesia, Fed. Sts."="Micronesia", "Russian Federation"="Russia", 
                                        "Slovak Republic"="Slovakia", "St. Lucia"="Saint Lucia", 
                                        "St. Martin (French part)"="Saint Martin",
                                        "St. Vincent and the Grenadines"="Saint Vincent", "Syrian Arab Republic"="Syria", 
                                        "Trinidad and Tobago"="Trinidad", "United Kingdom"="UK", "United States"="USA", 
                                        "Venezuela, RB"="Venezuela", "Virgin Islands (U.S.)"="Virgin Islands",
                                        "Yemen, Rep."="Yemen")
                        for (c in names((correction))) {
                          filtered[filtered$CountryName==c,"CountryName"] = correction[c]
                        }
                        
                        map.world <- merge(x=map_data(map="world"),
                                           y=filtered[,c("CountryName","Value")],
                                           by.x="region",
                                           by.y="CountryName",
                                           all.x=TRUE)
                        map.world <- map.world[order(map.world$order),]
                        
                        ggplot(map.world) +
                          geom_map(map=map.world, aes(map_id=region, x=long, y=lat, fill=Value)) + 
                          borders("world",colour="black")+
                          scale_fill_gradient(low = "blue", high = "red", guide = "colourbar") +
                          coord_equal() +
                          theme(axis.line=element_blank(),
                                axis.text.x=element_blank(),
                                axis.text.y=element_blank(),
                                axis.ticks=element_blank(),
                                axis.title.x=element_blank(),
                                axis.title.y=element_blank(),
                                panel.background=element_blank(),
                                panel.border=element_blank(),
                                panel.grid.major=element_blank(),
                                panel.grid.minor=element_blank(),
                                plot.background=element_blank(),
                                legend.title=element_blank(),
                                legend.position="bottom", 
                                legend.key.width = unit(6, "lines"),
                                legend.text = element_text(size = 10)
                                ) +
                          ggtitle(paste0(indicatorName, " in ", indicatorYear))
                        
                        
                      })
                      
                      data2 <- eventReactive(input$go, {
                        options(warn = -1)
                        ue <- Indicators %>%
                          filter(IndicatorName == input$Indicators) %>%
                          select(CountryName,Year,Value)  %>%
                          spread(Year,Value,sep="")
                        ue <- na.omit(ue)
                        cn<-ue$CountryName
                        
                        ue <- ue %>%
                          select(-CountryName) %>%
                          t() %>%
                          scale(center=TRUE,scale=FALSE) %>%
                          t()
                        
                        ue <- data.frame(cn,ue)
                        set.seed(1001)
                        fit <- kmeans(select(ue,-cn), centers=2,iter.max=100,nstart=1)
                        ue <- data.frame(ue, fit$cluster)
                        
                        ue <- ue %>%
                          gather(Year,Value,-c(cn,fit.cluster)) %>%
                          group_by(fit.cluster) %>%
                          mutate(cluster.count = n_distinct(cn)) %>%
                          ungroup() %>%
                          mutate(Year = as.numeric(gsub("Year","",Year)),
                                 fit.cluster = paste("Cluster ",fit.cluster," (",cluster.count," Countries)",sep=""))
                        
                        ggplot(ue,aes(Year,Value,colour=as.factor(fit.cluster)))+
                          geom_point(shape=1)+geom_smooth()+
                          scale_colour_discrete(guide=FALSE)+
                          ggtitle(paste0("Change in ", input$Indicators, " Between ", data()$FirstYear, " and ", data()$LastYear ))+
                          labs(x="Year",y= paste0(input$Indicators, " Rate(scaled)"))+
                          facet_wrap(~fit.cluster)
                      })
                      
                    data3 <- eventReactive(input$go, {
                      Indicators %>% 
                        filter(IndicatorName == input$Indicators) -> mData
                      mData %>% 
                        filter(Year == data()$FirstYear) %>% 
                        select(CountryCode) -> conSet
                      cData = left_join(conSet, mData, by = "CountryCode")
                      cData %>%
                        group_by(CountryCode) %>% 
                        mutate(Growth = 1 + Value / 100) %>% 
                        mutate(CumGrowth = cumprod(Growth)) %>% 
                        ungroup() %>% 
                        select(CountryName, Year, CumGrowth) -> growth
                      growth %>% 
                        filter(Year == data()$LastYear) %>% 
                        arrange(desc(CumGrowth)) %>% 
                        select(CountryName) %>% 
                        slice(1:10) -> top5Cont
                      top5 = left_join(top5Cont, growth, "CountryName")
                      print(ggplot(data=top5, 
                                   aes(x=Year, y=(CumGrowth - 1) * 100, 
                                       group=CountryName, colour=CountryName)) + 
                              geom_line(size = 1.2) + 
                              ggtitle(paste0("Top 10 Performing ", input$Indicators)) + 
                              ylab("Cummulative Percentage Growth"))
                      
                      
                      
                    })
                      
                    data4 <- eventReactive(input$go, {
                      Indicators %>% 
                        filter(IndicatorName == input$Indicators) -> mData
                      mData %>% 
                        filter(Year == data()$FirstYear) %>% 
                        select(CountryCode) -> conSet
                      cData = left_join(conSet, mData, by = "CountryCode")
                      cData %>%
                        group_by(CountryCode) %>% 
                        mutate(Growth = 1 + Value / 100) %>% 
                        mutate(CumGrowth = cumprod(Growth)) %>% 
                        ungroup() %>% 
                        select(CountryName, Year, CumGrowth) -> growth
                      growth %>% 
                        filter(Year == data()$LastYear) %>% 
                        arrange(CumGrowth) %>% 
                        select(CountryName) %>% 
                        slice(1:10) -> bot5Cont
                      
                      bot5 = left_join(bot5Cont, growth, "CountryName")
                      print(ggplot(data=bot5, 
                                   aes(x=Year, y=(CumGrowth - 1) * 100, 
                                       group=CountryName, colour=CountryName)) + 
                              geom_line(size = 1.2) + 
                              ggtitle(paste0("Bottom 10 Performing ", input$Indicators)) + 
                              ylab("Cummulative Percentage Growth"))
                      
                      
                      
                    })
                    data5 <- eventReactive(input$go, {
                      indicatorName <- input$Indicators 
                      indicatorYear <- input$Years 
                      filtered <- Indicators[Indicators$IndicatorName==indicatorName & Indicators$Year==indicatorYear,] 
                      correction <- c("Antigua and Barbuda"="Antigua", "Bahamas, The"="Bahamas", 
                                      "Brunei Darussalam"="Brunei", "Cabo Verde"="Cape Verde",
                                      "Congo, Dem. Rep."="Democratic Republic of the Congo", 
                                      "Congo, Rep."="Republic of Congo", "Cote d'Ivoire"="Ivory Coast", 
                                      "Egypt, Arab Rep."="Egypt", "Faeroe Islands"="Faroe Islands", 
                                      "Gambia, The"="Gambia", "Iran, Islamic Rep."="Iran", 
                                      "Korea, Dem. Rep."="North Korea", "Korea, Rep."="South Korea",
                                      "Kyrgyz Republic"="Kyrgyzstan", "Lao PDR"="Laos", "Macedonia, FYR"="Macedonia", 
                                      "Micronesia, Fed. Sts."="Micronesia", "Russian Federation"="Russia", 
                                      "Slovak Republic"="Slovakia", "St. Lucia"="Saint Lucia", 
                                      "St. Martin (French part)"="Saint Martin",
                                      "St. Vincent and the Grenadines"="Saint Vincent", "Syrian Arab Republic"="Syria", 
                                      "Trinidad and Tobago"="Trinidad", "United Kingdom"="UK", "United States"="USA", 
                                      "Venezuela, RB"="Venezuela", "Virgin Islands (U.S.)"="Virgin Islands",
                                      "Yemen, Rep."="Yemen") 
                      for (c in names((correction))) {
                        filtered[filtered$CountryName==c,"CountryName"] = correction[c]
                      }  
                      filtered
                    })
                    
                    data6 <- eventReactive(input$go, {
                      indicators.data <- Indicators
                      countires.data <- Country
                      
                      south.asia.region <- subset(countires.data, countires.data$Region == "South Asia")
                      
                      x <- merge(south.asia.region, indicators.data, by.x = "ShortName", by.y = "CountryName")
                      
                      x <- x[, c("Year", "ShortName", "IndicatorCode", "IndicatorName", "Value")] # just keep the needed columns..
                      
                    })

                    data21 <- eventReactive(input$go,{
                      world<-map_data("world")
                      world$region<-as.factor(world$region)
                      
                      correction <- c("Antigua and Barbuda"="Antigua", "Bahamas, The"="Bahamas", "Brunei Darussalam"="Brunei", "Cabo Verde"="Cape Verde", "Congo, Dem. Rep."="Democratic Republic of the Congo", "Congo, Rep."="Republic of Congo", "Cote d'Ivoire"="Ivory Coast", "Egypt, Arab Rep."="Egypt", "Faeroe Islands"="Faroe Islands", "Gambia, The"="Gambia", "Iran, Islamic Rep."="Iran", "Korea, Dem. Rep."="North Korea", "Korea, Rep."="South Korea", "Kyrgyz Republic"="Kyrgyzstan", "Lao PDR"="Laos", "Macedonia, FYR"="Macedonia", "Micronesia, Fed. Sts."="Micronesia", "Russian Federation"="Russia", "Slovak Republic"="Slovakia", "St. Lucia"="Saint Lucia", "St. Martin (French part)"="Saint Martin", "St. Vincent and the Grenadines"="Saint Vincent", "Syrian Arab Republic"="Syria", "Trinidad and Tobago"="Trinidad", "United Kingdom"="UK", "United States"="USA", "Venezuela, RB"="Venezuela", "Virgin Islands (U.S.)"="Virgin Islands", "Yemen, Rep."="Yemen")
                      
                      for(i in names(correction)){
                        Indicators[Indicators$CountryName==i,"CountryName"]<-correction[i]
                      }
                      
                      my_miss<-function(df){
                        a_list<-c(1960:2014)[which(!(c(1960:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss2<-function(df){
                        a_list<-c(1985,1989:2013)[which(!(c(1985,1989:2013)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss3<-function(df){
                        a_list<-c(1988:2014)[which(!(c(1988:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      in_arms_india<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.MPRT.KD"&Indicators$CountryName=="India"),][,c("Year","Value")]
                      in_arms_china<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.MPRT.KD"&Indicators$CountryName=="China"),][,c("Year","Value")]
                      in_arms_pakistan<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.MPRT.KD"&Indicators$CountryName=="Pakistan"),][,c("Year","Value")]
                      in_arms_vietnam<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.MPRT.KD"&Indicators$CountryName=="Vietnam"),][,c("Year","Value")]
                      in_arms_vietnam<-my_miss(in_arms_vietnam)
                      in_arms_bangladesh<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.MPRT.KD"&Indicators$CountryName=="Bangladesh"),][,c("Year","Value")]
                      in_arms_bangladesh<-my_miss(in_arms_bangladesh)
                      in_arms_myanmar<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.MPRT.KD"&Indicators$CountryName=="Myanmar"),][,c("Year","Value")]
                      in_arms_myanmar<-my_miss(in_arms_myanmar)
                      import_south<-cbind(in_arms_india,in_arms_china[,2],in_arms_pakistan[,2],in_arms_vietnam[,2],in_arms_bangladesh[,2],in_arms_myanmar[,2])
                      colnames(import_south)<-c("Year","India","China","Pakistan","Vietnam","Bangladesh","Myanmar")
                      
                      plot_ly(import_south,x=~Year,y=~India)%>%
                        add_lines(y=~India,name="India")%>%
                        add_lines(y=~China,name="China")%>%
                        add_lines(y=~Pakistan,name="Pakistan")%>%
                        add_lines(y=~Vietnam,name="Vietnam")%>%
                        add_lines(y=~Bangladesh,name="Bangladesh")%>%
                        add_lines(y=~Myanmar,name="Myanmar")%>%
                        layout(title="Arms Imports by Countries",
                               yaxis=list(title="Value"),
                               annotations=list(x=1.1,
                                                y=1.02,
                                                xref="paper",
                                                yref="paper",
                                                text="Country",
                                                showarrow=F))
                    })
                    
                    data22 <- eventReactive(input$go,{
                      world<-map_data("world")
                      world$region<-as.factor(world$region)
                      
                      correction <- c("Antigua and Barbuda"="Antigua", "Bahamas, The"="Bahamas", "Brunei Darussalam"="Brunei", "Cabo Verde"="Cape Verde", "Congo, Dem. Rep."="Democratic Republic of the Congo", "Congo, Rep."="Republic of Congo", "Cote d'Ivoire"="Ivory Coast", "Egypt, Arab Rep."="Egypt", "Faeroe Islands"="Faroe Islands", "Gambia, The"="Gambia", "Iran, Islamic Rep."="Iran", "Korea, Dem. Rep."="North Korea", "Korea, Rep."="South Korea", "Kyrgyz Republic"="Kyrgyzstan", "Lao PDR"="Laos", "Macedonia, FYR"="Macedonia", "Micronesia, Fed. Sts."="Micronesia", "Russian Federation"="Russia", "Slovak Republic"="Slovakia", "St. Lucia"="Saint Lucia", "St. Martin (French part)"="Saint Martin", "St. Vincent and the Grenadines"="Saint Vincent", "Syrian Arab Republic"="Syria", "Trinidad and Tobago"="Trinidad", "United Kingdom"="UK", "United States"="USA", "Venezuela, RB"="Venezuela", "Virgin Islands (U.S.)"="Virgin Islands", "Yemen, Rep."="Yemen")
                      
                      for(i in names(correction)){
                        Indicators[Indicators$CountryName==i,"CountryName"]<-correction[i]
                      }
                      
                      my_miss<-function(df){
                        a_list<-c(1960:2014)[which(!(c(1960:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss2<-function(df){
                        a_list<-c(1985,1989:2013)[which(!(c(1985,1989:2013)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss3<-function(df){
                        a_list<-c(1988:2014)[which(!(c(1988:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      ex_arms_india<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPRT.KD"&Indicators$CountryName=="India"),][,c("Year","Value")]
                      ex_arms_india<-my_miss(ex_arms_india)
                      ex_arms_china<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPRT.KD"&Indicators$CountryName=="China"),][,c("Year","Value")]
                      ex_arms_pakistan<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPRT.KD"&Indicators$CountryName=="Pakistan"),][,c("Year","Value")]
                      ex_arms_pakistan<-my_miss(ex_arms_pakistan)
                      ex_arms_vietnam<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPRT.KD"&Indicators$CountryName=="Vietnam"),][,c("Year","Value")]
                      ex_arms_vietnam<-my_miss(ex_arms_vietnam)
                      ex_arms_bangladesh<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPRT.KD"&Indicators$CountryName=="Bangladesh"),][,c("Year","Value")]
                      ex_arms_myanmar<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPRT.KD"&Indicators$CountryName=="Myanmar"),][,c("Year","Value")]
                      export_south<-cbind(ex_arms_india,ex_arms_china[,2],ex_arms_pakistan[,2],ex_arms_vietnam[,2],ex_arms_bangladesh[,2])
                      colnames(export_south)<-c("Year","India","China","Pakistan","Vietnam","Bangladesh")
                      
                      plot_ly(export_south,x=~Year,y=~India)%>%
                        add_lines(y=~India,name="India")%>%
                        add_lines(y=~China,name="China")%>%
                        add_lines(y=~Pakistan,name="Pakistan")%>%
                        add_lines(y=~Vietnam,name="Vietnam")%>%
                        add_lines(y=~Bangladesh,name="Bangladesh")%>%
                        layout(title="Arms Exports by Countries",
                               yaxis=list(title="Value"),
                               annotations=list(x=1.1,
                                                y=1.02,
                                                xref="paper",
                                                yref="paper",
                                                text="Country",
                                                showarrow=F))
                    })  
                    
                    
                    data23 <- eventReactive(input$go,{
                      world<-map_data("world")
                      world$region<-as.factor(world$region)
                      
                      correction <- c("Antigua and Barbuda"="Antigua", "Bahamas, The"="Bahamas", "Brunei Darussalam"="Brunei", "Cabo Verde"="Cape Verde", "Congo, Dem. Rep."="Democratic Republic of the Congo", "Congo, Rep."="Republic of Congo", "Cote d'Ivoire"="Ivory Coast", "Egypt, Arab Rep."="Egypt", "Faeroe Islands"="Faroe Islands", "Gambia, The"="Gambia", "Iran, Islamic Rep."="Iran", "Korea, Dem. Rep."="North Korea", "Korea, Rep."="South Korea", "Kyrgyz Republic"="Kyrgyzstan", "Lao PDR"="Laos", "Macedonia, FYR"="Macedonia", "Micronesia, Fed. Sts."="Micronesia", "Russian Federation"="Russia", "Slovak Republic"="Slovakia", "St. Lucia"="Saint Lucia", "St. Martin (French part)"="Saint Martin", "St. Vincent and the Grenadines"="Saint Vincent", "Syrian Arab Republic"="Syria", "Trinidad and Tobago"="Trinidad", "United Kingdom"="UK", "United States"="USA", "Venezuela, RB"="Venezuela", "Virgin Islands (U.S.)"="Virgin Islands", "Yemen, Rep."="Yemen")
                      
                      for(i in names(correction)){
                        Indicators[Indicators$CountryName==i,"CountryName"]<-correction[i]
                      }
                      
                      my_miss<-function(df){
                        a_list<-c(1960:2014)[which(!(c(1960:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss2<-function(df){
                        a_list<-c(1985,1989:2013)[which(!(c(1985,1989:2013)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss3<-function(df){
                        a_list<-c(1988:2014)[which(!(c(1988:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      force_india<-my_miss2(Indicators[which(Indicators$IndicatorCode=="MS.MIL.TOTL.P1"&Indicators$CountryName=="India"),][,c("Year","Value")])
                      force_china<-my_miss2(Indicators[which(Indicators$IndicatorCode=="MS.MIL.TOTL.P1"&Indicators$CountryName=="China"),][,c("Year","Value")])
                      force_pakistan<-my_miss2(Indicators[which(Indicators$IndicatorCode=="MS.MIL.TOTL.P1"&Indicators$CountryName=="Pakistan"),][,c("Year","Value")])
                      force_vietnam<-my_miss2(Indicators[which(Indicators$IndicatorCode=="MS.MIL.TOTL.P1"&Indicators$CountryName=="Vietnam"),][,c("Year","Value")])
                      force_bangladesh<-my_miss2(Indicators[which(Indicators$IndicatorCode=="MS.MIL.TOTL.P1"&Indicators$CountryName=="Bangladesh"),][,c("Year","Value")])
                      force_myanmar<-my_miss2(Indicators[which(Indicators$IndicatorCode=="MS.MIL.TOTL.P1"&Indicators$CountryName=="Myanmar"),][,c("Year","Value")])
                      force_south<-cbind(force_india,force_china[,2],force_pakistan[,2],force_vietnam[,2],force_bangladesh[,2],force_myanmar[,2])
                      colnames(force_south)<-c("Year","India","China","Pakistan","Vietnam","Bangladesh","Myanmar")
                      
                      plot_ly(force_south,x=~Year,y=~India)%>%
                        add_lines(y=~India,name="India")%>%
                        add_lines(y=~China,name="China")%>%
                        add_lines(y=~Pakistan,name="Pakistan")%>%
                        add_lines(y=~Vietnam,name="Vietnam")%>%
                        add_lines(y=~Bangladesh,name="Bangladesh")%>%
                        add_lines(y=~Myanmar,name="Myanmar")%>%
                        layout(title="Armed Forces (Total Personnel)",
                               yaxis=list(title="Value"),
                               annotations=list(x=1.1,
                                                y=1.02,
                                                xref="paper",
                                                yref="paper",
                                                text="Country",
                                                showarrow=F))
                    })
                    
                    
                    data24 <- eventReactive(input$go,{
                      world<-map_data("world")
                      world$region<-as.factor(world$region)
                      
                      correction <- c("Antigua and Barbuda"="Antigua", "Bahamas, The"="Bahamas", "Brunei Darussalam"="Brunei", "Cabo Verde"="Cape Verde", "Congo, Dem. Rep."="Democratic Republic of the Congo", "Congo, Rep."="Republic of Congo", "Cote d'Ivoire"="Ivory Coast", "Egypt, Arab Rep."="Egypt", "Faeroe Islands"="Faroe Islands", "Gambia, The"="Gambia", "Iran, Islamic Rep."="Iran", "Korea, Dem. Rep."="North Korea", "Korea, Rep."="South Korea", "Kyrgyz Republic"="Kyrgyzstan", "Lao PDR"="Laos", "Macedonia, FYR"="Macedonia", "Micronesia, Fed. Sts."="Micronesia", "Russian Federation"="Russia", "Slovak Republic"="Slovakia", "St. Lucia"="Saint Lucia", "St. Martin (French part)"="Saint Martin", "St. Vincent and the Grenadines"="Saint Vincent", "Syrian Arab Republic"="Syria", "Trinidad and Tobago"="Trinidad", "United Kingdom"="UK", "United States"="USA", "Venezuela, RB"="Venezuela", "Virgin Islands (U.S.)"="Virgin Islands", "Yemen, Rep."="Yemen")
                      
                      for(i in names(correction)){
                        Indicators[Indicators$CountryName==i,"CountryName"]<-correction[i]
                      }
                      
                      my_miss<-function(df){
                        a_list<-c(1960:2014)[which(!(c(1960:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss2<-function(df){
                        a_list<-c(1985,1989:2013)[which(!(c(1985,1989:2013)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss3<-function(df){
                        a_list<-c(1988:2014)[which(!(c(1988:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      mili_ex_LUC_india<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.CN"&Indicators$CountryName=="India"),][,c("Year","Value")]
                      mili_ex_LUC_china<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.CN"&Indicators$CountryName=="China"),][,c("Year","Value")]
                      mili_ex_LUC_china<-my_miss3(mili_ex_LUC_china)
                      mili_ex_LUC_pakistan<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.CN"&Indicators$CountryName=="Pakistan"),][,c("Year","Value")]
                      mili_ex_LUC_vietnam<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.CN"&Indicators$CountryName=="Vietnam"),][,c("Year","Value")]
                      mili_ex_LUC_vietnam<-my_miss3(mili_ex_LUC_vietnam)
                      mili_ex_LUC_bangladesh<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.CN"&Indicators$CountryName=="Bangladesh"),][,c("Year","Value")]
                      mili_ex_LUC_myanmar<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.CN"&Indicators$CountryName=="Myanmar"),][,c("Year","Value")]
                      mili_ex_LUC_myanmar<-my_miss3(mili_ex_LUC_myanmar)
                      
                      mili_ex_LUC_india$Value<-mili_ex_LUC_india$Value*0.0155533
                      mili_ex_LUC_china$Value<-mili_ex_LUC_china$Value*0.144838
                      mili_ex_LUC_pakistan$Value<-mili_ex_LUC_pakistan$Value*0.00954426
                      mili_ex_LUC_vietnam$Value<-mili_ex_LUC_vietnam$Value*0.0000441014
                      mili_ex_LUC_bangladesh$Value<-mili_ex_LUC_bangladesh$Value*0.0124471
                      mili_ex_LUC_myanmar$Value<-mili_ex_LUC_myanmar$Value*0.000737463
                      
                      mili_ex_LUC_total<-cbind(mili_ex_LUC_china,mili_ex_LUC_india[,2],mili_ex_LUC_pakistan[,2],mili_ex_LUC_vietnam[,2],mili_ex_LUC_bangladesh[,2],mili_ex_LUC_myanmar[,2])
                      colnames(mili_ex_LUC_total)<-c("Year","India","China","Pakistan","Vietnam","Bangladesh","Myanmar")
                      
                      plot_ly(mili_ex_LUC_total,x=~Year,y=~India)%>%
                        add_lines(y=~India,name="India")%>%
                        add_lines(y=~China,name="China")%>%
                        add_lines(y=~Pakistan,name="Pakistan")%>%
                        add_lines(y=~Vietnam,name="Vietnam")%>%
                        add_lines(y=~Bangladesh,name="Bangladesh")%>%
                        add_lines(y=~Myanmar,name="Myanmar")%>%
                        layout(title="Military expenditure",
                               yaxis=list(title="USD"),
                               annotations=list(x=1.1,
                                                y=1.02,
                                                xref="paper",
                                                yref="paper",
                                                text="Country",
                                                showarrow=F))
                    })
                    
                    data25 <- eventReactive(input$go,{
                      world<-map_data("world")
                      world$region<-as.factor(world$region)
                      
                      correction <- c("Antigua and Barbuda"="Antigua", "Bahamas, The"="Bahamas", "Brunei Darussalam"="Brunei", "Cabo Verde"="Cape Verde", "Congo, Dem. Rep."="Democratic Republic of the Congo", "Congo, Rep."="Republic of Congo", "Cote d'Ivoire"="Ivory Coast", "Egypt, Arab Rep."="Egypt", "Faeroe Islands"="Faroe Islands", "Gambia, The"="Gambia", "Iran, Islamic Rep."="Iran", "Korea, Dem. Rep."="North Korea", "Korea, Rep."="South Korea", "Kyrgyz Republic"="Kyrgyzstan", "Lao PDR"="Laos", "Macedonia, FYR"="Macedonia", "Micronesia, Fed. Sts."="Micronesia", "Russian Federation"="Russia", "Slovak Republic"="Slovakia", "St. Lucia"="Saint Lucia", "St. Martin (French part)"="Saint Martin", "St. Vincent and the Grenadines"="Saint Vincent", "Syrian Arab Republic"="Syria", "Trinidad and Tobago"="Trinidad", "United Kingdom"="UK", "United States"="USA", "Venezuela, RB"="Venezuela", "Virgin Islands (U.S.)"="Virgin Islands", "Yemen, Rep."="Yemen")
                      
                      for(i in names(correction)){
                        Indicators[Indicators$CountryName==i,"CountryName"]<-correction[i]
                      }
                      
                      my_miss<-function(df){
                        a_list<-c(1960:2014)[which(!(c(1960:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss2<-function(df){
                        a_list<-c(1985,1989:2013)[which(!(c(1985,1989:2013)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      my_miss3<-function(df){
                        a_list<-c(1988:2014)[which(!(c(1988:2014)%in%df[,"Year"][[1]]))]
                        a_list<-data.frame(matrix(c(a_list,rep(NA,length(a_list))),ncol=2))
                        colnames(a_list)<-c("Year","Value")
                        df<-rbind(df,a_list)
                      }
                      
                      mili_ex_GDP_india<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.GD.ZS"&Indicators$CountryName=="India"),][,c("Year","Value")]
                      mili_ex_GDP_china<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.GD.ZS"&Indicators$CountryName=="China"),][,c("Year","Value")]
                      mili_ex_GDP_china<-my_miss3(mili_ex_GDP_china)
                      mili_ex_GDP_pakistan<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.GD.ZS"&Indicators$CountryName=="Pakistan"),][,c("Year","Value")]
                      
                      mili_ex_GDP_vietnam<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.GD.ZS"&Indicators$CountryName=="Vietnam"),][,c("Year","Value")]
                      mili_ex_GDP_vietnam<-my_miss3(mili_ex_GDP_vietnam)
                      mili_ex_GDP_bangladesh<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.GD.ZS"&Indicators$CountryName=="Bangladesh"),][,c("Year","Value")]
                      mili_ex_GDP_myanmar<-Indicators[which(Indicators$IndicatorCode=="MS.MIL.XPND.GD.ZS"&Indicators$CountryName=="Myanmar"),][,c("Year","Value")]
                      mili_ex_GDP_myanmar<-my_miss3(mili_ex_GDP_myanmar)
                      force_vietnam<-my_miss2(Indicators[which(Indicators$IndicatorCode=="MS.MIL.TOTL.P1"&Indicators$CountryName=="Vietnam"),][,c("Year","Value")])
                      mili_ex_GDP_total<-cbind(mili_ex_GDP_india,mili_ex_GDP_china[,2],mili_ex_GDP_pakistan[,2],mili_ex_GDP_vietnam[,2],mili_ex_GDP_bangladesh[,2],mili_ex_GDP_myanmar[,2])
                      colnames(mili_ex_GDP_total)<-c("Year","India","China","Pakistan","Vietnam","Bangladesh","Myanmar")
                      
                      
                      plot_ly(mili_ex_GDP_total,x=~Year,y=~India)%>%
                        add_lines(y=~India,name="India")%>%
                        add_lines(y=~China,name="China")%>%
                        add_lines(y=~Pakistan,name="Pakistan")%>%
                        add_lines(y=~Vietnam,name="Vietnam")%>%
                        add_lines(y=~Bangladesh,name="Bangladesh")%>%
                        add_lines(y=~Myanmar,name="Myanmar")%>%
                        layout(title="Military expenditure",
                               yaxis=list(title="% of GDP"),
                               annotations=list(x=1.1,
                                                y=1.02,
                                                xref="paper",
                                                yref="paper",
                                                text="Country",
                                                showarrow=F))
                      
                    })
                    
                   
                       output$plot1 <- renderPlot({ data1()})
                       output$table <- renderTable({data5()})
                       output$plot2 <- renderPlot({ data2()})
                       output$plot3 <- renderPlot({ data3()})
                       output$plot4 <- renderPlot({ data4()})
                       output$plot5 <- renderPlot({
                         # fixed telephone subscribers per 100 persons
                         fixed.telephones.per100.persons <- subset(data6(), data6()$IndicatorCode == "IT.MLT.MAIN.P2" )
                         
                         ggplot(fixed.telephones.per100.persons) + aes(x = Year, y = Value) + geom_point() + 
                           ggtitle("Fixed Telephones per 100 persons")  + facet_wrap(~ShortName)
                       })
                       output$plot6 <- renderPlot({
                         # mobile data subscriptions
                         mobile.data <- subset(data6(), data6()$IndicatorCode == "IT.CEL.SETS.P2")
                         
                         ggplot(mobile.data) + aes(x = Year, y = Value) + geom_point(color = "blue") + 
                           labs(x = "Year", y = "Subscriptions per 100 persons") + ggtitle("Mobile Subscribers") + facet_wrap(~ShortName)
                         
                       })
                       output$plot7 <- renderPlot({
                         # population in largest city
                         popln.data <- subset(data6(), data6()$IndicatorCode == "EN.URB.LCTY.UR.ZS")
                         
                         ggplot(popln.data) + aes(x = Year, y = Value) + geom_point(color = "blue") + 
                           labs(x = "Year", y = "% of Urban Population") + ggtitle("Population in largest city") + facet_wrap(~ShortName)
                       })
                       output$plot8 <- renderPlot({
                         # population distribution by age groups in percents
                         # SP.POP.65UP.TO.ZS ;SP.POP.0014.TO.ZS ;SP.POP.1564.TO.ZS
                         population.by.age <- subset(data6(), data6()$IndicatorCode == "SP.POP.65UP.TO.ZS" | data6()$IndicatorCode == "SP.POP.0014.TO.ZS" |
                                                       data6()$IndicatorCode == "SP.POP.1564.TO.ZS")
                         ggplot(population.by.age) + aes(x = Year, y = Value, colour = IndicatorName) + 
                           geom_point(stat = "identity") + facet_wrap(~ShortName)
                       })
                       output$plot9 <- renderPlot({
                         female.popl.percent.total <- subset(data6(), data6()$IndicatorCode == "SP.POP.TOTL.FE.ZS")
                         
                         ggplot(female.popl.percent.total) + aes(x  = Year, y = Value) + geom_point(color = "red") +
                           labs(x = "Year", y = "% population") + ggtitle("Percentage of total female population") + facet_wrap(~ShortName)
                       })
                       output$plot10 <- renderPlot({
                         # population growth in annual perctange
                         
                         population.growth.annual <- subset(data6(), data6()$IndicatorCode == "SP.POP.GROW")
                         ggplot(population.growth.annual) + aes(x = Year, y = Value) +
                           ggtitle("Annual piopulation growth") +labs(x = "Year", y = "Growth percent") + geom_line(size = 1) +
                           facet_wrap(~ShortName)
                         
                       })
                       output$plot11 <- renderPlot({
                         # Electric power consumption (kWh per capita)	EG.USE.ELEC.KH.PC
                         # Electric power transmission and distribution losses (% of output)	EG.ELC.LOSS.ZS
                         # Electricity production from coal sources (% of total)	EG.ELC.COAL.ZS
                         # Electricity production from hydroelectric sources (% of total)	EG.ELC.HYRO.ZS
                         # Electricity production from natural gas sources (% of total)	EG.ELC.NGAS.ZS
                         # Electricity production from nuclear sources (% of total)	EG.ELC.NUCL.ZS
                         # Electricity production from oil sources (% of total)	EG.ELC.PETR.ZS
                         # Electricity production from oil, gas and coal sources (% of total)	EG.ELC.FOSL.ZS
                         # Electricity production from renewable sources, excluding hydroelectric (% of total)	EG.ELC.RNWX.ZS
                         # Electricity production from renewable sources, excluding hydroelectric (kWh)	EG.ELC.RNWX.KH
                         
                         electricity.production <- subset(data6(), data6()$IndicatorCode == "EG.ELC.COAL.ZS" | data6()$IndicatorCode == "EG.ELC.HYRO.ZS" |
                                                            data6()$IndicatorCode == "EG.ELC.NGAS.ZS" | data6()$IndicatorCode == "EG.ELC.NUCL.ZS" |
                                                            data6()$IndicatorCode == "EG.ELC.PETR.ZS" | data6()$IndicatorCode == "EG.ELC.FOSL.ZS" |
                                                            data6()$IndicatorCode == "EG.ELC.RWNX.ZS")
                         ggplot(electricity.production) + aes(x = Year, y = Value, color = IndicatorName) + 
                           ggtitle("Electricity production") + geom_line(size = 1) + facet_wrap(~ShortName)
                         
                       })
                       output$plot12 <- renderPlot({
                         # plot the electric power consumption
                         electric.power.consumption <- subset(data6(), data6()$IndicatorCode == "EG.USE.ELEC.KH.PC")
                         
                         ggplot(electric.power.consumption) + aes(x = Year, y = Value, color = ShortName) + ggtitle("Electric Power consumption") +
                           labs(x = "Year", y = "KWh per capita") + geom_line(size = 1)
                       })
                       output$plot13 <- renderPlot({
                         # life expectancies at birth (years), female: SP.DYN.LE00.FE.IN; male: SP.DYN.LE00.MA.IN; total: SP.DYN.LE00.IN
                         
                         life.expectancies <- subset(data6(), data6()$IndicatorCode == "SP.DYN.LE00.FE.IN" | data6()$IndicatorCode ==
                                                       "SP.DYN.LE00.MA.IN" | data6()$IndicatorCode == "SP.DYN.LE00.IN")
                         
                         ggplot(life.expectancies) +
                           aes(x = Year, y = Value, color = IndicatorName) +  geom_point() +
                           ggtitle("Life expectancies at birth (in years)") + facet_wrap(~ShortName)  
                       })
                       output$plot14 <- renderPlot({
                         # fertility rate data
                         fertility.data <- subset(data6(), data6()$IndicatorCode == "SP.DYN.TFRT.IN")
                         
                         ggplot(fertility.data) + aes(x  = Year, y = Value) + geom_point(color = "red", shape = 10) +
                           labs(x = "Year", y = "Total births per woman ") + ggtitle("Fertility Rates") + facet_wrap(~ShortName)
                       })
                       output$plot15 <- renderPlot({
                         # hospital beds per 1000 persons
                         hospital.beds.per1000 <- subset(data6(), data6()$IndicatorCode == "SH.MED.BEDS.ZS")
                         
                         ggplot(hospital.beds.per1000) + aes(x = Year, y = Value) + geom_point() +
                           ggtitle("Hospital beds per 1000 persons") + facet_wrap(~ShortName)
                       })
                       output$plot16 <- renderPlot({
                         # food imports and exports
                         patt <- "Food*[ ]*im*.*" # look for Food followed by a space followed by im and everything else
                         patt1 <- "Food*[ ]*ex*.*"
                         a <- grep(patt, data6()$IndicatorName, value = TRUE)
                         a1 <- grep(patt1, data6()$IndicatorName, value = TRUE)
                         food.imports.exports <- subset(data6(), data6()$IndicatorName == a | data6()$IndicatorName == a1 )
                         ggplot(food.imports.exports) + aes(x = Year, y = Value, color = IndicatorName) + 
                           labs(x = "Years", y = "% import/export") +
                           ggtitle("Food import/export visualization") + geom_line(size = 1) + facet_wrap(~ShortName)
                         
                       })
                       output$plot17 <- renderPlot({
                         
                         # improved water source
                         water.sources.access <- subset(data6(), data6()$IndicatorName == "Improved water source (% of population with access)" |
                                                          data6()$IndicatorName == "Improved water source, rural (% of rural population with access)" |
                                                          data6()$IndicatorName == "Improved water source, urban (% of urban population with access)"  )
                         
                         ggplot(water.sources.access) + aes(x = Year, y = Value, color = IndicatorName) + geom_point(size = 1) +
                           labs(x = "Year", y = "Percent of population with access") + ggtitle("Improved water source access to people") +
                           facet_wrap(~ShortName)
                       })
                       output$plot18 <- renderPlot({
                         # fuels pump prices
                         fuel.prices <- subset(data6(), data6()$IndicatorName == "Pump price for diesel fuel (US$ per liter)" |
                                                 data6()$IndicatorName ==  "Pump price for gasoline (US$ per liter)" )
                         
                         ggplot(fuel.prices) + aes(x = Year, y = Value, color = IndicatorName) + geom_line(size = 1) +
                           labs(y = "Pump price of fuel (US dollar/liter)") + ggtitle("Variation of fuel prices at pumps") + 
                           facet_wrap(~ShortName)
                       })                      
                       output$plot19 <- renderPlot({
                         # Unemployment with primary education (% of total unemployment)	SL.UEM.PRIM.ZS
                         # Unemployment with primary education, female (% of female unemployment)	SL.UEM.PRIM.FE.ZS
                         # Unemployment with primary education, male (% of male unemployment)	SL.UEM.PRIM.MA.ZS
                         # Unemployment with secondary education (% of total unemployment)	SL.UEM.SECO.ZS
                         # Unemployment with secondary education, female (% of female unemployment)	SL.UEM.SECO.FE.ZS
                         # Unemployment with secondary education, male (% of male unemployment)	SL.UEM.SECO.MA.ZS
                         # Unemployment with tertiary education (% of total unemployment)	SL.UEM.TERT.ZS
                         # Unemployment with tertiary education, female (% of female unemployment)	SL.UEM.TERT.FE.ZS
                         # Unemployment with tertiary education, male (% of male unemployment)	SL.UEM.TERT.MA.ZS
                         
                         unemployment.data.by.eduction.level <- subset(data6(), data6()$IndicatorCode == "SL.UEM.PRIM.ZS" | 
                                                                         data6()$IndicatorCode == "SL.UEM.PRIM.FE.ZS" | data6()$IndicatorCode == "SL.UEM.PRIM.MA.ZS" |
                                                                         data6()$IndicatorCode == "SL.UEM.SECO.ZS" | data6()$IndicatorCode =="SL.UEM.SECO.FE.ZS" |
                                                                         data6()$IndicatorCode == "SL.UEM.SECO.MA.ZS" | data6()$IndicatorCode =="SL.UEM.TERT.ZS" |
                                                                         data6()$IndicatorCode == "SL.UEM.TERT.FE.ZS" | data6()$IndicatorCode == "SL.UEM.TERT.MA.ZS") 
                         
                         # ggplot(unemployment.data.by.eduction.level) + aes(x = Year, y = Value) + ggtitle("Unemployment by education") +
                         # labs(x = "Years", y = "Percentage unemployed") + geom_line(size = 1) + facet_wrap(ShortName~IndicatorName)   
                         
                         ggplot(unemployment.data.by.eduction.level) + aes(x = Year, y = Value, color = ShortName) + 
                           ggtitle("Unemployment by education") +
                           labs(x = "Years", y = "Percentage unemployed") + geom_line(size = 1) + facet_wrap(~IndicatorName) 
                       })
                       output$plot20 <- renderPlotly({data21()})
                       output$plot21 <- renderPlotly({data22()})
                       output$plot22 <- renderPlotly({data23()})
                       output$plot23 <- renderPlotly({data24()})
                       output$plot24 <- renderPlotly({data25()})
                       
})
shinyApp(ui = ui, server = server)